import time
import datetime

# print(time.ctime())

# # print month
# print(time.strftime('%m'))
# print(time.strftime('%d'))
# print(time.strftime('%Y'))
# print(time.strftime('%m,%d,%Y'))
print(datetime.datetime.now())