import pickle as pkl
from decouple import config
class Prediction:
    _instance = None  # Class variable to store the singleton instance
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(Prediction, cls).__new__(cls)
            # Initialize the instance only once
            cls._instance.initialize()
        return cls._instance
    
    def reset(cls):
        cls._instance = None
    def initialize(self):
        self.model_name = config('USE_MODEL')
        self.model = pkl.load(open(f"ds/models/{self.model_name}.pkl", 'rb'))
        self.scaler = pkl.load(open(f"ds/scalers/{self.model_name}.pkl", 'rb'))
    def predict(self, question):
        answer = self.model.predict(self.scaler.transform(question))
        return answer