import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report
import pickle as pkl
import time
class TrainingModel():
    def __init__(self,file_name,model_name):
        start_time = time.time()
        self._initialize(file_name,model_name)
        self._preprocessing()
        self.df_report = self._training()
        end_time = time.time()
        self.total_time = end_time - start_time # in seconds
        
    def get_report(self):
        return self.df_report.to_dict(),self.total_time
    
    def _initialize(self,file_name,model_name):
        self.path_file = "data_storage/"+file_name+".csv"
        self.dataset = pd.read_csv(self.path_file)
        self.model_name =model_name + '_' + str(time.time())
    def _preprocessing(self):
        dataset_ = self.dataset.drop(columns=['Serial No.'])
        dataset_['Chance of Admit'] = dataset_['Chance of Admit'].apply(lambda x: 1 if x >= 0.5 else 0)
        self.X_train, self.X_test, self.y_train, self.y_test = train_test_split(dataset_.drop(columns=['Chance of Admit']), dataset_['Chance of Admit'], test_size=0.2, random_state=42)
        scaler = StandardScaler()
        scaler.fit(self.X_train)
        self.scaler = scaler
        pkl.dump(scaler, open(f"ds/scalers/{self.model_name}.pkl", "wb"))
    
    def _training(self):
        model = LogisticRegression()
        model.fit(self.scaler.transform(self.X_train), self.y_train)
        pkl.dump(model, open(f"ds/models/{self.model_name}.pkl", "wb"))
        y_hat = model.predict(self.scaler.transform(self.X_test))
        report = classification_report(self.y_test,y_hat,output_dict=True)
        df_report = pd.DataFrame(report).transpose()
        return df_report        