from django.urls import path
from .views import ChatbotAPI
urlpatterns = [
    path('chatbotapi/', ChatbotAPI.as_view(), name='chatbotapi'),
]
