from django.apps import AppConfig


class SecretkeyConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "secretkey"
