from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from monitoring.models import NotAnsweredQuestion,QuestionMonitor
# Create your views here.
class UnAnsweredAPI(APIView):
    def get(self,request):
        unanswered = NotAnsweredQuestion.objects.all().values()
        return Response({'unanswered':unanswered}, status=status.HTTP_200_OK)
    def delete(self,request):
        id = request.query_params.get('id')
        model = NotAnsweredQuestion.objects.filter(id=id)
        if model:
            model.delete()
            return Response({'message':'Delete Success'}, status=status.HTTP_200_OK)
        else:
            return Response({'error':'Delete Failed'}, status=status.HTTP_400_BAD_REQUEST)

class QuestionMonitorAPI(APIView):
    def get(self,request):
        question_monitor = QuestionMonitor.objects.all().values()
        return Response({'question_monitor':question_monitor}, status=status.HTTP_200_OK)